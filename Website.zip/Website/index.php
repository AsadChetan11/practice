<?php 
include 'header.php';
include 'slider.php';
include 'promosection.php';
include 'productsection.php';
include 'popularsection.php';
include 'supportsection.php';
include 'footer.php';



?>